I made input fields for username and password and set their values as required.
I stored the token in local storage with the name 'token'
