const express =require('express')
const todoModel =require('../../models/todos')
const router = express.Router();

router.get('/', async(req,res)=>{
    const todos = await todoModel.find();
    res.send(todos);
    console.log(todos)
})

router.get('/:id',async(req,res)=>{
    const todo = await todoModel.findById(req.params.id);
    res.send(todo)
})

router.post('/add-todo',async(req,res)=>{
    const todo = new todoModel();
    todo.name=req.body.name;
    todo.price=req.body.price;
    todo.description=req.body.description;

    await todo.save();
    res.send(todo);
})

router.delete('/delete/:id', async(req,res)=>{
    let model = await todoModel.findById(req.params.id)
    await model.delete();
    res.send("Successfully Deleted")
})
module.exports = router;