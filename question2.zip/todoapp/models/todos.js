const mongoose  =require('mongoose')

let todoSchema =mongoose.Schema({
    name:String,
    price:Number,
    description:String,
})

let todoModel = mongoose.model('todos',todoSchema)
module.exports=todoModel;